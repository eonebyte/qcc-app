export default function Orders() {
  return (
    <div>
      <h1>Sales Order</h1>
    </div>
  )
}
